<?php
include 'partials/ptheader.php';
require __DIR__ . '/users/users.php';


if (!isset($_POST['id'])) {
    include "partials/not_found.php";
    exit;
}
$userId = $_POST['id'];
deleteUser($userId);

header("Location: api.php");

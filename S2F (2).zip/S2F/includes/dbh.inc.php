<?php

//databases
$serverName= "localhost:3307";
$dbUsername= "root";
$dBPassword= "";
$dBName= "test_db";

//connection to databases
$conn= mysqli_connect($serverName, $dbUsername, $dBPassword, $dBName);

//Error message if connection fails
if(!$conn){
  die("Connection failed: " . mysqli_connect_error());
}
